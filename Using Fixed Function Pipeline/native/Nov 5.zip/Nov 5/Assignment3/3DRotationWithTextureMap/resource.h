
#define MYBITMAP 101
#define MYBITMAP1 102


